 USE projeto02;
 
 INSERT INTO usuario (nome_usuario, email_usuario, fone_usuario)
 VALUES ('Evelin', 'evelinbonfim57@gmail.com', '9090-7070');
 
 SELECT * FROM usuario;